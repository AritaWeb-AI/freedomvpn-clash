#!/usr/bin/env python3
import json
import os
import sys
import time
import uuid
import getpass
import subprocess
from typing import Any, Dict, List, Optional, Tuple

import requests


AUTH_URL = "https://auth.contabo.com/auth/realms/contabo/protocol/openid-connect/token"
API_BASE = "https://api.contabo.com/v1"

REGIONS = [
    "EU", "UK", "JPN", "SIN", "US-central", "US-east", "US-west", "AUS", "IND"
]

# Common Contabo VPS product IDs shown in API docs (not exhaustive).
# You can also just type your own productId if you know it.
COMMON_PRODUCTS = [
    ("V91", "VPS 10 NVMe (75GB)"),
    ("V92", "VPS 10 SSD (150GB)"),
    ("V94", "VPS 20 NVMe (100GB)"),
    ("V95", "VPS 20 SSD (200GB)"),
    ("V97", "VPS 30 NVMe (200GB)"),
    ("V98", "VPS 30 SSD (400GB)"),
]


def die(msg: str, code: int = 1) -> None:
    print(f"\n❌ {msg}\n", file=sys.stderr)
    raise SystemExit(code)


def prompt_choice(title: str, options: List[str], default: Optional[str] = None) -> str:
    print(f"\n{title}")
    for i, opt in enumerate(options, 1):
        tag = " (default)" if default == opt else ""
        print(f"  {i}. {opt}{tag}")
    while True:
        raw = input("Choose number (or press Enter for default): ").strip()
        if raw == "" and default:
            return default
        if raw.isdigit():
            idx = int(raw)
            if 1 <= idx <= len(options):
                return options[idx - 1]
        print("Invalid choice, try again.")


def prompt_text(label: str, default: Optional[str] = None, secret: bool = False) -> str:
    if secret:
        val = getpass.getpass(f"{label}: ")
        if not val:
            die(f"{label} cannot be empty.")
        return val
    if default:
        val = input(f"{label} (default: {default}): ").strip()
        return val if val else default
    val = input(f"{label}: ").strip()
    if not val:
        die(f"{label} cannot be empty.")
    return val


def read_file(path: str) -> str:
    path = os.path.expanduser(path)
    with open(path, "r", encoding="utf-8") as f:
        return f.read().strip()


def req_headers(token: str) -> Dict[str, str]:
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "x-request-id": str(uuid.uuid4()),
        "x-trace-id": "freedomvpn-bootstrap",
    }


def get_access_token(client_id: str, client_secret: str, api_user: str, api_password: str) -> str:
    data = {
        "client_id": client_id,
        "client_secret": client_secret,
        "username": api_user,
        "password": api_password,
        "grant_type": "password",
    }
    r = requests.post(AUTH_URL, data=data, timeout=30)
    if r.status_code != 200:
        die(f"Auth failed ({r.status_code}): {r.text}")
    tok = r.json().get("access_token")
    if not tok:
        die("Auth succeeded but no access_token returned.")
    return tok


def list_images(token: str, search: str) -> List[Dict[str, Any]]:
    params = {
        "search": search,
        "standardImage": "true",
        "size": "50",
        "page": "1",
        "orderBy": "name:asc",
    }
    r = requests.get(f"{API_BASE}/compute/images", headers=req_headers(token), params=params, timeout=30)
    if r.status_code != 200:
        die(f"List images failed ({r.status_code}): {r.text}")
    return r.json().get("data", [])


def list_secrets(token: str, type_filter: Optional[str] = None, name: Optional[str] = None) -> List[Dict[str, Any]]:
    params = {"size": "200", "page": "1", "orderBy": "name:asc"}
    if type_filter:
        params["type"] = type_filter
    if name:
        params["name"] = name
    r = requests.get(f"{API_BASE}/secrets", headers=req_headers(token), params=params, timeout=30)
    if r.status_code != 200:
        die(f"List secrets failed ({r.status_code}): {r.text}")
    return r.json().get("data", [])


def ensure_ssh_secret(token: str, secret_name: str, public_key: str) -> int:
    # Try reuse by exact name first
    existing = list_secrets(token, type_filter="ssh", name=secret_name)
    if existing:
        sid = existing[0].get("secretId")
        return int(sid)

    payload = {"name": secret_name, "value": public_key, "type": "ssh"}
    r = requests.post(f"{API_BASE}/secrets", headers=req_headers(token), data=json.dumps(payload), timeout=30)
    if r.status_code != 201:
        die(f"Create ssh secret failed ({r.status_code}): {r.text}")
    created = r.json()["data"][0]
    return int(created["secretId"])


def create_instance(
    token: str,
    region: str,
    product_id: str,
    image_id: str,
    ssh_secret_ids: List[int],
    display_name: str,
    period_months: int = 1,
    default_user: str = "root",
    user_data: Optional[str] = None,
) -> int:
    payload: Dict[str, Any] = {
        "imageId": image_id,
        "productId": product_id,
        "region": region,
        "sshKeys": ssh_secret_ids,
        "period": period_months,
        "displayName": display_name,
        "defaultUser": default_user,
    }
    if user_data:
        payload["userData"] = user_data

    r = requests.post(f"{API_BASE}/compute/instances", headers=req_headers(token), data=json.dumps(payload), timeout=60)
    if r.status_code != 201:
        die(f"Create instance failed ({r.status_code}): {r.text}")
    inst = r.json()["data"][0]
    return int(inst["instanceId"])


def get_instance(token: str, instance_id: int) -> Dict[str, Any]:
    r = requests.get(f"{API_BASE}/compute/instances/{instance_id}", headers=req_headers(token), timeout=30)
    if r.status_code != 200:
        die(f"Get instance failed ({r.status_code}): {r.text}")
    return r.json()["data"][0]


def wait_for_ipv4(token: str, instance_id: int, timeout_sec: int = 900) -> Tuple[str, Dict[str, Any]]:
    start = time.time()
    while True:
        inst = get_instance(token, instance_id)
        ip = None
        ipcfg = inst.get("ipConfig") or {}
        v4 = ipcfg.get("v4") or {}
        ip = v4.get("ip")
        status = inst.get("status")
        if ip:
            return ip, inst
        if time.time() - start > timeout_sec:
            die(f"Timeout waiting for IPv4 on instance {instance_id}. Last status={status}")
        print(f"⏳ waiting for IP... status={status}")
        time.sleep(10)


def run_ssh_command(host: str, cmd: str) -> None:
    # Uses system OpenSSH (works on Linux/macOS/Windows if ssh is installed)
    ssh_cmd = [
        "ssh",
        "-o", "StrictHostKeyChecking=accept-new",
        f"root@{host}",
        cmd,
    ]
    print(f"\n▶ SSH: {cmd}")
    r = subprocess.run(ssh_cmd)
    if r.returncode != 0:
        die(f"SSH command failed with exit code {r.returncode}")


def main() -> None:
    print("=== Contabo VM creator + FreedomVPN bootstrap ===")

    # Credentials: env first, prompt if missing
    client_id = os.getenv("CONTABO_CLIENT_ID") or prompt_text("CONTABO_CLIENT_ID")
    client_secret = os.getenv("CONTABO_CLIENT_SECRET") or prompt_text("CONTABO_CLIENT_SECRET", secret=True)
    api_user = os.getenv("CONTABO_API_USER") or prompt_text("CONTABO_API_USER (email)")
    api_password = os.getenv("CONTABO_API_PASSWORD") or prompt_text("CONTABO_API_PASSWORD", secret=True)

    token = get_access_token(client_id, client_secret, api_user, api_password)
    print("✅ Auth OK")

    region = prompt_choice("Pick region:", REGIONS, default="UK")

    # Product
    print("\nPick hardware tier (productId):")
    for i, (pid, desc) in enumerate(COMMON_PRODUCTS, 1):
        print(f"  {i}. {pid}  — {desc}")
    print("  0. Enter a custom productId")
    raw = input("Choose number (default 2 = V92): ").strip()
    if raw == "":
        product_id = "V92"
    elif raw == "0":
        product_id = prompt_text("Enter productId (e.g., V92)")
    elif raw.isdigit() and 1 <= int(raw) <= len(COMMON_PRODUCTS):
        product_id = COMMON_PRODUCTS[int(raw) - 1][0]
    else:
        die("Invalid product selection.")

    # OS Image
    os_search = prompt_text("OS search term", default="Ubuntu 22.04")
    images = list_images(token, os_search)
    if not images:
        die(f"No images found for search={os_search}")
    print("\nFound images:")
    shown = images[:10]
    for i, img in enumerate(shown, 1):
        name = img.get("name")
        ver = img.get("version")
        os_type = img.get("osType")
        iid = img.get("imageId")
        print(f"  {i}. {name}  (ver={ver}, os={os_type})  id={iid}")
    pick = input("Choose image number (default 1): ").strip()
    if pick == "":
        image_id = shown[0]["imageId"]
    elif pick.isdigit() and 1 <= int(pick) <= len(shown):
        image_id = shown[int(pick) - 1]["imageId"]
    else:
        die("Invalid image selection.")

    # SSH keys (2)
    key1_path = prompt_text("Path to SSH public key #1", default="~/.ssh/id_ed25519.pub")
    key2_path = prompt_text("Path to SSH public key #2", default="~/.ssh/id_ed25519_2.pub")
    key1 = read_file(key1_path)
    key2 = read_file(key2_path)

    secret1_name = prompt_text("Contabo Secret name for key #1", default="freedomvpn-sshkey-1")
    secret2_name = prompt_text("Contabo Secret name for key #2", default="freedomvpn-sshkey-2")
    sid1 = ensure_ssh_secret(token, secret1_name, key1)
    sid2 = ensure_ssh_secret(token, secret2_name, key2)
    print(f"✅ SSH secrets: {sid1}, {sid2}")

    display_name = prompt_text("VM displayName", default=f"FreedomVPN-{region}-{product_id}")
    period = int(prompt_text("Contract period months (1/3/6/12)", default="1"))

    instance_id = create_instance(
        token=token,
        region=region,
        product_id=product_id,
        image_id=image_id,
        ssh_secret_ids=[sid1, sid2],
        display_name=display_name,
        period_months=period,
        default_user="root",
    )
    print(f"✅ Created instanceId={instance_id}")

    ip, inst = wait_for_ipv4(token, instance_id)
    print(f"✅ VM IPv4: {ip}  status={inst.get('status')}")

    # Bootstrap: run your existing script on the new VM
    ss_password = prompt_text("Shadowsocks password (SS_PASSWORD)", secret=True)
    vmess_uuid = prompt_text("VMess UUID (VMESS_UUID)", default=str(uuid.uuid4()))
    role = prompt_text("Role (edge or sub)", default="edge")

    # Download + run the installer (you already use this repo/script)
    installer_url = "https://raw.githubusercontent.com/AritaWeb-AI/freedomvpn-clash/main/setup_freedomvpn_xray.py"
    remote_cmd = (
        f"set -e; "
        f"sudo apt-get update -y; sudo apt-get install -y python3 curl; "
        f"curl -fsSL '{installer_url}' -o /root/setup_freedomvpn_xray.py; "
        f"sudo SS_PASSWORD='{ss_password}' VMESS_UUID='{vmess_uuid}' "
        f"python3 /root/setup_freedomvpn_xray.py --role {role}; "
        f"sudo sed -i 's/^User=nobody/User=root/' /etc/systemd/system/xray.service || true; "
        f"sudo systemctl daemon-reload; sudo systemctl restart xray; "
        f"sudo ss -lntu | egrep '10101|10105' || true"
    )

    run_ssh_command(ip, remote_cmd)

    print("\n🎉 Done.")
    print(f"New VM: {display_name}  ({region})  IP={ip}")
    print("Next: add DNS record (uk2/eu2/etc) + update your subscription YAML if needed.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        die("Cancelled by user.", 130)
