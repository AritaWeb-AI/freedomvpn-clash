class FVPNError(Exception):
    pass
